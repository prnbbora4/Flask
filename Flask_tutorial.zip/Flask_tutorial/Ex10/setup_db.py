from main import db, Puppy
db.create_all()

tom = Puppy("Tom", 5)
frank = Puppy("Frank", 6)

print(tom.id)
print(frank.id)


db.session.add_all([tom, frank])
db.session.commit()

print(tom.id)
print(frank.id)
