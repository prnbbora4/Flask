from main import db, Puppy

##create
my_puppy = Puppy("Maity", 7)
db.session.add(my_puppy)
db.session.commit()


##Read
all_puppies = Puppy.query.all()
print(all_puppies)


##Select by id
puppy_one = Puppy.query.get(1)
print(puppy_one.name)

##Filter
puppy_frank = Puppy.query.filter_by(name = "Frank")
print(puppy_frank.all())


##Update
first_puppy = Puppy.query.get(1)
first_puppy.age = 10
db.session.add(first_puppy)
db.session.commit()


##Delete
second_pup = Puppy.query.get(2)
db.session.delete(second_pup)
db.session.commit()


##Final table value

all_pups = Puppy.query.all()
print(all_pups)
