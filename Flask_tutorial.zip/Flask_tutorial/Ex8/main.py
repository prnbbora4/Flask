from flask import Flask, flash, render_template, session, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField


app = Flask(__name__)

app.config['SECRET_KEY'] = 'thefreaking'

class SimpleForm(FlaskForm):
    name = StringField('Enter your name')
    submit = SubmitField('Click Me')



@app.route('/', methods = ['GET', 'POST'])
def index():
        form = SimpleForm()

        if form.validate_on_submit():
            session['name'] = form.name.data
            flash("You just click the botton")


            return redirect(url_for('index'))

        return render_template('index.html', form=form)



if __name__ == '__main__':
    app.run(debug=True)
