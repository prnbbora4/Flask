from flask import Flask

app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello World !"

@app.route("/friend")
def friend():
    return "Hello friend"

@app.route("/friend/<username>")
def name(username):
    return "Hello friend , {}".format(username)

if __name__=="__main__":
    app.run()
