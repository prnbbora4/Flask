from model import db, Puppy, Toy, Owner

tom = Puppy("Tom")
frank = Puppy("Frank")

db.session.add_all([tom, frank])
db.session.commit()

puppies = Puppy.query.all()
print(puppies)

prnb = Owner("Pranab", tom.id)

toy1 = Toy("Ball", tom.id)
toy2 = Toy("Bat", tom.id)


db.session.add_all([prnb, toy1, toy2])
db.session.commit()


owners = Owner.query.all()
print(owners)

toys = Toy.query.all()
print(toys)


puppies1 = Puppy.query.all()
print(puppies1)
