from flask import Flask, render_template, session, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import (StringField, BooleanField, RadioField, TextAreaField, TextField,  DateTimeField, SelectField, SubmitField)
from wtforms.validators import DataRequired


app = Flask(__name__)

app.config['SECRET_KEY'] = 'thefreaking'

class InfoForm(FlaskForm):
    name = StringField('Please enter your name', validators=[DataRequired()])
    mood = RadioField("Please select your choice", choices=[('mood_one', 'Happy'), ('mood_two', 'Excited')])
    food = SelectField(u'Please select your choice', choices=[('chi', 'Chicken'), ('fish', 'Fish'), ('veg', 'Vegetables')])
    feedback = TextAreaField()
    submit = SubmitField('Submit')


@app.route('/', methods = ['GET', 'POST'])
def index():
        form = InfoForm()

        if form.validate_on_submit():
            session['name'] = form.name.data
            session['mood'] = form.mood.data
            session['food'] = form.food.data
            session['feedback'] = form.feedback.data

            return redirect(url_for('thankyou'))

        return render_template('index.html', form=form)



@app.route('/thankyou')
def thankyou():
    return render_template('thankyou.html')



if __name__ == '__main__':
    app.run(debug=True)
